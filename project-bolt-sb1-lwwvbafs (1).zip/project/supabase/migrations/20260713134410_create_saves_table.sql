/*
# Create saves table for The Last Witness (single-tenant, no auth)

1. New Tables
- `saves`
  - `id` (uuid, primary key)
  - `slot` (text, not null) — a client-chosen save slot name (e.g. "auto", "slot-1")
  - `player_name` (text, not null) — the name the player entered at the prologue
  - `state` (jsonb, not null) — full serializable game state: current chapter, collected evidence ids, discovered clues, suspicion level, accusation result, contacts visited, etc.
  - `updated_at` (timestamptz, default now())
2. Security
- Enable RLS on `saves`.
- This is a no-auth single-player narrative game; there is no sign-in screen.
- Allow anon + authenticated full CRUD because save data is intentionally shared/public per device.
- `USING (true)` / `WITH CHECK (true)` is documented as intentional for this public single-tenant table.
3. Notes
- One row per (slot) per device; the frontend upserts on slot.
- An index on `slot` speeds lookups.
*/

CREATE TABLE IF NOT EXISTS saves (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slot text NOT NULL,
  player_name text NOT NULL DEFAULT 'Witness',
  state jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE saves ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_saves" ON saves;
CREATE POLICY "anon_select_saves" ON saves FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_saves" ON saves;
CREATE POLICY "anon_insert_saves" ON saves FOR INSERT
TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_saves" ON saves;
CREATE POLICY "anon_update_saves" ON saves FOR UPDATE
TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_saves" ON saves;
CREATE POLICY "anon_delete_saves" ON saves FOR DELETE
TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS saves_slot_idx ON saves (slot);

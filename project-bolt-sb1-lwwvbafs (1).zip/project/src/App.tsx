import { useCallback, useEffect, useState } from "react";
import {
  type GameState,
  type SceneId,
  type SuspectId,
  type EvidenceId,
  initialGameState,
  MEETINGS,
  SUSPECTS,
} from "./game/data";
import { useSaves, useSaveGame, useDeleteSave, type SaveSummary } from "./hooks/saveGame";
import { TitleScreen } from "./components/TitleScreen";
import { PrologueScene } from "./components/PrologueScene";
import { WarehouseScene } from "./components/WarehouseScene";
import { CityChaseScene } from "./components/CityChaseScene";
import { MeetingScene } from "./components/MeetingScene";
import { ContactsHub } from "./components/ContactsHub";
import { EvidenceBoard, AccusationScene } from "./components/EvidenceBoard";
import { BroadcastScene } from "./components/BroadcastScene";
import { EndingScene } from "./components/EndingScene";

export default function App() {
  const [state, setState] = useState<GameState>(initialGameState);
  const [pendingMeeting, setPendingMeeting] = useState<string | null>(null);
  const { saves, loading, refresh } = useSaves();
  const { save } = useSaveGame();
  const { remove } = useDeleteSave();

  const persist = useCallback(
    (next: GameState) => {
      setState(next);
      void save(next);
    },
    [save],
  );

  useEffect(() => {
    refresh();
  }, [refresh]);

  const startNewGame = () => {
    const fresh = initialGameState();
    fresh.scene = "prologue";
    setState(fresh);
  };

  const continueSave = (save: SaveSummary) => {
    setState({ ...initialGameState(), ...save.state });
  };

  const deleteSave = async (slot: string) => {
    const ok = await remove(slot);
    if (ok) refresh();
  };

  const completePrologue = (name: string) => {
    persist({ ...state, playerName: name, scene: "warehouse" });
  };

  const onWarehouseComplete = () => {
    persist({ ...state, scene: "city_chase" });
  };
  const onWarehouseCaught = () => {
    persist({ ...state, scene: "city_chase" });
  };

  const onChaseComplete = () => {
    const next: GameState = {
      ...state,
      scene: "contacts",
      suspicion: Math.min(state.suspicionMax, state.suspicion + 10),
    };
    persist(next);
  };
  const onChaseCaught = () => {
    persist({ ...state, scene: "contacts", suspicion: state.suspicion + 20 });
  };

  const pickMeeting = (meetingId: string) => {
    if (meetingId === "evidence_board") {
      persist({ ...state, scene: "evidence_board" });
      return;
    }
    const meeting = MEETINGS.find((m) => m.id === meetingId);
    if (!meeting) return;
    setPendingMeeting(meetingId);
    persist({ ...state, scene: meeting.scene });
  };

  const onClueCollected = (clue: string, evidence: EvidenceId | undefined) => {
    setState((prev) => {
      const clues = prev.clues.includes(clue) ? prev.clues : [...prev.clues, clue];
      const evidenceList = evidence && !prev.evidence.includes(evidence)
        ? [...prev.evidence, evidence]
        : prev.evidence;
      const visited = pendingMeeting
        ? { ...prev.visited, [meetingVisitedKey(pendingMeeting)]: true }
        : prev.visited;
      return { ...prev, clues, evidence: evidenceList, visited };
    });
  };

  const exitMeeting = () => {
    setPendingMeeting(null);
    setState((prev) => {
      const next: GameState = { ...prev, scene: "contacts" as SceneId };
      void save(next);
      return next;
    });
  };

  const reviewDone = () => {
    persist({ ...state, scene: "accusation" });
  };

  const accuse = (suspect: SuspectId) => {
    const suspectData = SUSPECTS[suspect];
    if (suspectData.isTraitor) {
      persist({ ...state, accusation: suspect, scene: "broadcast" });
    } else {
      const wrongs = state.wrongAccusations + 1;
      persist({
        ...state,
        accusation: suspect,
        wrongAccusations: wrongs,
        scene: "ending_wrong",
      });
    }
  };

  const backToContacts = () => {
    persist({ ...state, scene: "contacts" });
  };

  const onBroadcastComplete = () => {
    persist({ ...state, scene: "ending_truth" });
  };

  const playAgain = () => {
    startNewGame();
  };
  const backToTitle = () => {
    setState(initialGameState());
    refresh();
  };

  switch (state.scene) {
    case "title":
      return (
        <TitleScreen
          saves={saves}
          loadingSaves={loading}
          onNewGame={startNewGame}
          onContinue={continueSave}
          onDeleteSave={deleteSave}
        />
      );
    case "prologue":
      return <PrologueScene onComplete={completePrologue} />;
    case "warehouse":
      return (
        <WarehouseScene onComplete={onWarehouseComplete} onCaught={onWarehouseCaught} />
      );
    case "city_chase":
      return <CityChaseScene onComplete={onChaseComplete} onCaught={onChaseCaught} />;
    case "meeting_bilal":
    case "meeting_khan":
    case "meeting_maira":
    case "meeting_usman": {
      const meeting = MEETINGS.find((m) => m.scene === state.scene);
      if (!meeting) return <ContactsHub state={state} onPick={pickMeeting} />;
      return (
        <MeetingScene
          meeting={meeting}
          playerName={state.playerName}
          onClueCollected={onClueCollected}
          onExit={exitMeeting}
        />
      );
    }
    case "contacts":
      return <ContactsHub state={state} onPick={pickMeeting} />;
    case "evidence_board":
      return <EvidenceBoard state={state} onReviewDone={reviewDone} />;
    case "accusation":
      return <AccusationScene state={state} onAccuse={accuse} onBack={backToContacts} />;
    case "broadcast":
      return <BroadcastScene onComplete={onBroadcastComplete} />;
    case "ending_truth":
      return (
        <EndingScene
          variant="truth"
          state={state}
          onPlayAgain={playAgain}
          onTitle={backToTitle}
        />
      );
    case "ending_caught":
      return (
        <EndingScene
          variant="caught"
          state={state}
          onPlayAgain={playAgain}
          onTitle={backToTitle}
        />
      );
    case "ending_wrong":
      return (
        <EndingScene
          variant="wrong"
          state={state}
          onPlayAgain={
            state.wrongAccusations >= state.maxWrong ? playAgain : backToContacts
          }
          onTitle={backToTitle}
        />
      );
    default:
      return (
        <TitleScreen
          saves={saves}
          loadingSaves={loading}
          onNewGame={startNewGame}
          onContinue={continueSave}
          onDeleteSave={deleteSave}
        />
      );
  }
}

function meetingVisitedKey(meetingId: string): keyof GameState["visited"] {
  return meetingId as keyof GameState["visited"];
}

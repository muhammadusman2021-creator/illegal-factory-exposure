export type EvidenceId =
  | "phone_recording"
  | "threatening_text"
  | "bank_transfers"
  | "khan_badge"
  | "gps_tracker"
  | "photo_usman_malik"
  | "sealed_news_article"
  | "burner_sim";

export type SuspectId = "bilal" | "khan" | "maira" | "usman";

export type SceneId =
  | "title"
  | "prologue"
  | "warehouse"
  | "city_chase"
  | "contacts"
  | "meeting_bilal"
  | "meeting_khan"
  | "meeting_maira"
  | "meeting_usman"
  | "evidence_board"
  | "accusation"
  | "broadcast"
  | "ending_truth"
  | "ending_caught"
  | "ending_wrong";

export type EvidenceItem = {
  id: EvidenceId;
  name: string;
  description: string;
  icon: string;
};

export type Suspect = {
  id: SuspectId;
  name: string;
  role: string;
  portrait: string;
  description: string;
  isTraitor: boolean;
  wrongReason: string;
  rightReason: string;
};

export type DialogueLine = {
  speaker: string;
  text: string;
};

export type ContactMeeting = {
  id: SuspectId;
  title: string;
  location: string;
  objective: string;
  scene: SceneId;
  meetingHeading: string;
  intro: string;
  lines: DialogueLine[];
  clue: string;
  clueEvidence?: EvidenceId;
  exitLabel: string;
  visitedKey: keyof GameState["visited"];
};

export type GameState = {
  playerName: string;
  scene: SceneId;
  evidence: EvidenceId[];
  clues: string[];
  visited: {
    bilal: boolean;
    khan: boolean;
    maira: boolean;
    usman: boolean;
  };
  suspicion: number;
  suspicionMax: number;
  accusation: SuspectId | null;
  contactsRemaining: number;
  wrongAccusations: number;
  maxWrong: number;
};

export const initialGameState = (): GameState => ({
  playerName: "",
  scene: "title",
  evidence: [],
  clues: [],
  visited: { bilal: false, khan: false, maira: false, usman: false },
  suspicion: 0,
  suspicionMax: 100,
  accusation: null,
  contactsRemaining: 3,
  wrongAccusations: 0,
  maxWrong: 2,
});

export const EVIDENCE: Record<EvidenceId, EvidenceItem> = {
  phone_recording: {
    id: "phone_recording",
    name: "Phone Recording",
    description:
      "The video you recorded on your phone. It shows Malik's men committing the crime — faces clear, voices audible. The evidence that started everything.",
    icon: "video",
  },
  threatening_text: {
    id: "threatening_text",
    name: "Threatening Text",
    description:
      "A text sent to your phone: 'We know who you are. Drop the video or your family is next.' Sent from a number tied to Khan's contact list.",
    icon: "message",
  },
  bank_transfers: {
    id: "bank_transfers",
    name: "Bank Transfer Records",
    description:
      "Printouts showing large transfers from shell companies to accounts tied to city officials. Dates match the crimes you recorded.",
    icon: "document",
  },
  khan_badge: {
    id: "khan_badge",
    name: "Khan's Badge Number",
    description:
      "Khan's badge belongs to Unit 7 — which was disbanded two years ago. He's been operating under a cover that no longer exists.",
    icon: "badge",
  },
  gps_tracker: {
    id: "gps_tracker",
    name: "GPS Tracker Log",
    description:
      "A tracker you planted on Khan's car. The log shows he visited Malik's warehouse three times this week — each time after telling you he was at the station.",
    icon: "map",
  },
  photo_usman_malik: {
    id: "photo_usman_malik",
    name: "Photo of Usman with Malik",
    description:
      "An old photo your professor doesn't know you have. It shows him shaking hands with Malik at a private event. It could be nothing. It could be everything.",
    icon: "photo",
  },
  sealed_news_article: {
    id: "sealed_news_article",
    name: "Sealed News Article",
    description:
      "A news article from three years ago about a witness who disappeared after cooperating with 'an honest officer.' The officer's name: Khan.",
    icon: "newspaper",
  },
  burner_sim: {
    id: "burner_sim",
    name: "Burner SIM Card",
    description:
      "A SIM card used by the gang for coordination. The call history reveals a web of contacts — including one inside the police.",
    icon: "sim",
  },
};

export const SUSPECTS: Record<SuspectId, Suspect> = {
  bilal: {
    id: "bilal",
    name: "Bilal",
    role: "Childhood friend, taxi driver",
    portrait: "bilal",
    description:
      "Your oldest friend. He knows every alley in this city. He owes you his life and wouldn't hesitate to risk it again.",
    isTraitor: false,
    wrongReason:
      "Bilal? He drove you through gunfire without blinking. He's the only reason you're alive. Look at someone else.",
    rightReason: "",
  },
  khan: {
    id: "khan",
    name: "Inspector Khan",
    role: "Honest police officer",
    portrait: "khan",
    description:
      "He's protected from the inside. Half my department is on his payroll. I can't move until I have enough to take to a judge I trust — and the recording could be that evidence.",
    isTraitor: true,
    wrongReason: "",
    rightReason:
      "Correct. Khan has been Malik's man inside the police for years. Every witness who trusted him disappeared. You were next.",
  },
  maira: {
    id: "maira",
    name: "Maira",
    role: "Investigative journalist",
    portrait: "maira",
    description:
      "You're the student who recorded Malik. I've been waiting for someone with proof for three years.",
    isTraitor: false,
    wrongReason:
      "Maira risked her career and her life on this story. Accusing her only helps the people she's fighting. Try again.",
    rightReason: "",
  },
  usman: {
    id: "usman",
    name: "Professor Usman",
    role: "University professor",
    portrait: "usman",
    description:
      "I've taught you for four years. I taught you to believe in justice. If you can't trust that, then trust the evidence. Follow it wherever it leads — even to me.",
    isTraitor: false,
    wrongReason:
      "The professor is naïve, maybe compromised — but he's not the leak. He didn't know the route, the recording, or your name. Think about who did.",
    rightReason: "",
  },
};

export const MEETINGS: ContactMeeting[] = [
  {
    id: "bilal",
    title: "The Witness",
    location: "Bilal's taxi, parked in an alley",
    objective: "Reach the safe house before the gang catches you",
    scene: "meeting_bilal",
    meetingHeading: "Meeting Bilal",
    intro: "The city roars around you. Horns, shouts, footsteps. They're closing in.",
    lines: [
      { speaker: "Bilal", text: "Get in. Quick. They're watching the main road." },
      { speaker: "You", text: "How did you know I'd come this way?" },
      { speaker: "Bilal", text: "Does it matter? I've known you since we were kids. I'm not going to let them take you." },
      { speaker: "You", text: "Then let's get you somewhere safe. I know a place. No one will find you there." },
      { speaker: "Bilal", text: "Which friend? I didn't tell anyone my route." },
      { speaker: "You", text: "It matters. The gang knew I was at the warehouse before I even left. Someone is feeding them." },
    ],
    clue:
      "Bilal didn't know your route, your name, or the recording. Only four people knew you had it: you, Bilal, Inspector Khan, and your professor.",
    clueEvidence: "burner_sim",
    exitLabel: "Continue to a contact",
    visitedKey: "bilal",
  },
  {
    id: "khan",
    title: "The Gathering Dark",
    location: "Meeting Inspector Khan at a safe house",
    objective: "Decide whether Khan can be trusted",
    scene: "meeting_khan",
    meetingHeading: "Meeting with Khan",
    intro: "The warehouse stinks of diesel. Somewhere a metal door bangs in the wind.",
    lines: [
      { speaker: "Khan", text: "Saad. I'm glad you came. I know you're frightened. You have every right to be." },
      { speaker: "You", text: "How did you find me? I didn't go to the police." },
      { speaker: "Khan", text: "I've been investigating Malik's gang for eight months. Off the books. I have informants everywhere. When I heard someone recorded them, I knew it was you." },
      { speaker: "You", text: "Eight months. And you haven't arrested him yet?" },
      { speaker: "Khan", text: "He's protected from the inside. Half my department is on his payroll. I can't move until I have enough to take to a judge I trust — and the recording could be that evidence." },
      { speaker: "You", text: "I need to know I can trust you." },
      { speaker: "Khan", text: "Then don't trust anyone. Trust me. When have I ever let you down?" },
    ],
    clue:
      "Khan's badge belongs to Unit 7 — disbanded two years ago. A previous witness who trusted him vanished without a trace. And he claims to have 'informants everywhere' — including, perhaps, your location.",
    clueEvidence: "khan_badge",
    exitLabel: "Return to your contacts",
    visitedKey: "khan",
  },
  {
    id: "maira",
    title: "The Truth",
    location: "Maira at her independent news office",
    objective: "Find a way to publish the recording safely",
    scene: "meeting_maira",
    meetingHeading: "Meeting Maira",
    intro: "The office smells of ink and old paper. A single lamp burns over a desk stacked with files.",
    lines: [
      { speaker: "Maira", text: "You're the student who recorded Malik. I've been waiting for someone with proof for three years." },
      { speaker: "You", text: "You published a story about the recording. That was two days ago. The gang found my identity the same day." },
      { speaker: "Maira", text: "I didn't name you. I didn't describe you. The story said 'a citizen captured evidence of Malik's gang on video.' That's all." },
      { speaker: "You", text: "Only four people knew I had that recording. Me, Bilal, Inspector Khan, and you." },
      { speaker: "Maira", text: "Can you publish the full story? Names, evidence, everything?" },
      { speaker: "You", text: "The system is what's broken. The police are compromised. An inspector named Khan says he can help, but I'm not sure." },
    ],
    clue:
      "Maira published the story, but she never knew your name, your route, or your face. Whoever burned your identity knew all three — and knew them before the story ran.",
    clueEvidence: "sealed_news_article",
    exitLabel: "Return to your contacts",
    visitedKey: "maira",
  },
  {
    id: "usman",
    title: "The Betrayal",
    location: "Professor Usman at the university, late evening",
    objective: "Seek legal guidance from your mentor",
    scene: "meeting_usman",
    meetingHeading: "Meeting Professor Usman",
    intro: "The campus is empty. Footsteps echo in the marble corridor as you climb the stairs.",
    lines: [
      { speaker: "Usman", text: "Saad. I heard what happened. The whole campus is talking about it." },
      { speaker: "You", text: "Professor. I need legal advice. I recorded a crime and now the gang is hunting me." },
      { speaker: "Usman", text: "The law is clear — you have protection as a witness. You should go to the judiciary, file a petition, let the system work." },
      { speaker: "You", text: "The system is what's broken. The police are compromised. An inspector named Khan says he can help, but I'm not sure." },
      { speaker: "Usman", text: "I've taught you for four years. I taught you to believe in justice. If you can't trust that, then trust the evidence. Follow it wherever it leads — even to me." },
      { speaker: "You", text: "I found an old photo of you, Professor. You were shaking hands with Malik at a private event." },
    ],
    clue:
      "Usman is photographed shaking hands with Malik at a private event. He told you he'd never met the man. But he never knew your route, your name, or the recording's existence.",
    clueEvidence: "photo_usman_malik",
    exitLabel: "Return to your contacts",
    visitedKey: "usman",
  },
];

export const ALL_EVIDENCE_IDS: EvidenceId[] = [
  "phone_recording",
  "threatening_text",
  "bank_transfers",
  "khan_badge",
  "gps_tracker",
  "photo_usman_malik",
  "sealed_news_article",
  "burner_sim",
];

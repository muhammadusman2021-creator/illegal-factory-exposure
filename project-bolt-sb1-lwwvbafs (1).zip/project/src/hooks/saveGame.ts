import { useEffect, useRef, useState } from "react";
import { supabase, supabaseConfigured, type SaveRow } from "../lib/supabase";
import { type GameState, initialGameState } from "../game/data";

const SLOT = "auto";

export type SaveSummary = {
  id: string;
  slot: string;
  playerName: string;
  updatedAt: string;
  scene: string;
  evidenceCount: number;
  state: GameState;
};

function toSummary(row: SaveRow): SaveSummary {
  const state = row.state ?? initialGameState();
  return {
    id: row.id,
    slot: row.slot,
    playerName: row.player_name,
    updatedAt: row.updated_at,
    scene: state.scene,
    evidenceCount: state.evidence?.length ?? 0,
    state,
  };
}

export function useSaves() {
  const [saves, setSaves] = useState<SaveSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refresh = async () => {
    if (!supabaseConfigured) {
      setLoading(false);
      setSaves([]);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase
        .from("saves")
        .select("id, slot, player_name, state, updated_at")
        .order("updated_at", { ascending: false });
      if (error) throw error;
      setSaves((data as SaveRow[]).map(toSummary));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load saves");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refresh();
  }, []);

  return { saves, loading, error, refresh };
}

export function useSaveGame() {
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const save = async (state: GameState) => {
    if (!supabaseConfigured) return true;
    setSaving(true);
    setError(null);
    try {
      const { error } = await supabase.from("saves").upsert(
        {
          slot: SLOT,
          player_name: state.playerName || "Witness",
          state: state as unknown as Record<string, unknown>,
          updated_at: new Date().toISOString(),
        },
        { onConflict: "slot" },
      );
      if (error) throw error;
      return true;
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to save");
      return false;
    } finally {
      setSaving(false);
    }
  };

  return { save, saving, error };
}

export function useDeleteSave() {
  const [deleting, setDeleting] = useState(false);

  const remove = async (slot: string) => {
    if (!supabaseConfigured) return true;
    setDeleting(true);
    try {
      const { error } = await supabase.from("saves").delete().eq("slot", slot);
      if (error) throw error;
      return true;
    } catch {
      return false;
    } finally {
      setDeleting(false);
    }
  };

  return { remove, deleting };
}

export function useTypewriter(text: string, speed = 28, enabled = true) {
  const [displayed, setDisplayed] = useState(enabled ? "" : text);
  const [done, setDone] = useState(!enabled);
  const timer = useRef<number | null>(null);

  useEffect(() => {
    if (!enabled) {
      setDisplayed(text);
      setDone(true);
      return;
    }
    setDisplayed("");
    setDone(false);
    let i = 0;
    const tick = () => {
      i += 1;
      setDisplayed(text.slice(0, i));
      if (i >= text.length) {
        setDone(true);
        return;
      }
      timer.current = window.setTimeout(tick, speed);
    };
    timer.current = window.setTimeout(tick, speed);
    return () => {
      if (timer.current) window.clearTimeout(timer.current);
    };
  }, [text, speed, enabled]);

  const skip = () => {
    if (timer.current) window.clearTimeout(timer.current);
    setDisplayed(text);
    setDone(true);
  };

  return { displayed, done, skip };
}

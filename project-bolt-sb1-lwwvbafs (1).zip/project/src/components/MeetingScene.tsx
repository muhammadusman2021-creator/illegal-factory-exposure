import { useState } from "react";
import { AmbientBackground, ChapterHeader, GameButton, EvidenceIcon } from "./ui";
import { useTypewriter } from "../hooks/saveGame";
import type { ContactMeeting, EvidenceId } from "../game/data";
import { EVIDENCE } from "../game/data";

export function MeetingScene({
  meeting,
  playerName,
  onClueCollected,
  onExit,
}: {
  meeting: ContactMeeting;
  playerName: string;
  onClueCollected: (clue: string, evidence: EvidenceId | undefined) => void;
  onExit: () => void;
}) {
  const [lineIndex, setLineIndex] = useState(0);
  const [showClue, setShowClue] = useState(false);
  const total = meeting.lines.length;
  const current = meeting.lines[lineIndex];
  const { displayed, done, skip } = useTypewriter(current.text, 26, !showClue);
  const isPlayer = current.speaker === "You";

  const advance = () => {
    if (!done) {
      skip();
      return;
    }
    if (lineIndex < total - 1) {
      setLineIndex((i) => i + 1);
      return;
    }
    setShowClue(true);
    onClueCollected(meeting.clue, meeting.clueEvidence);
  };

  const speakerName = isPlayer
    ? playerName || "You"
    : current.speaker;

  return (
    <AmbientBackground>
      <ChapterHeader title={meeting.title} subtitle={meeting.location} />
      <div className="px-6 pt-4 text-center">
        <p className="text-[10px] uppercase tracking-[0.2em] text-ink-500">Objective</p>
        <p className="mt-1 text-sm text-ink-300">{meeting.objective}</p>
      </div>

      <div className="flex flex-1 flex-col justify-center px-6 py-6">
        {!showClue ? (
          <div className="mx-auto w-full max-w-xl" onClick={advance} role="button" tabIndex={0}>
            <p className="mb-3 text-center font-cinzel text-sm italic text-ink-400">
              {meeting.intro}
            </p>
            <div className="min-h-[5rem] rounded-lg border border-ink-700 bg-ink-800/50 p-5">
              <p
                className={`text-xs uppercase tracking-[0.2em] ${
                  isPlayer ? "text-ember-400" : "text-rust-400"
                }`}
              >
                {speakerName}
              </p>
              <p className="mt-2 font-cinzel text-lg leading-relaxed text-ink-100 sm:text-xl">
                {displayed}
                <span className={`ml-0.5 inline-block ${done ? "hidden" : "animate-pulse-glow"}`}>▋</span>
              </p>
            </div>
            <div className="mt-4 flex items-center justify-between">
              <div className="flex gap-1.5">
                {meeting.lines.map((_, i) => (
                  <span
                    key={i}
                    className={`h-1.5 w-1.5 rounded-full ${
                      i === lineIndex ? "bg-ember-500" : i < lineIndex ? "bg-ink-500" : "bg-ink-700"
                    }`}
                  />
                ))}
              </div>
              <p className="text-[10px] uppercase tracking-[0.2em] text-ink-500">
                {done ? "Tap to continue" : ""}
              </p>
            </div>
          </div>
        ) : (
          <div className="mx-auto w-full max-w-xl animate-fade-in space-y-5">
            <div className="rounded-lg border border-ember-600/40 bg-ember-500/5 p-5">
              <p className="text-xs uppercase tracking-[0.2em] text-ember-400">
                Suspicious Observations
              </p>
              <p className="mt-2 text-sm leading-relaxed text-ink-100">
                {meeting.clue}
              </p>
            </div>
            {meeting.clueEvidence && (
              <div className="flex items-center gap-4 rounded-lg border border-ink-700 bg-ink-800/60 p-4">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-md border border-ember-600/40 bg-ember-500/10 text-ember-400">
                  <EvidenceIcon icon={EVIDENCE[meeting.clueEvidence].icon} />
                </div>
                <div>
                  <p className="text-xs uppercase tracking-[0.2em] text-ink-400">
                    Evidence Collected
                  </p>
                  <p className="font-cinzel text-sm font-semibold text-ink-100">
                    {EVIDENCE[meeting.clueEvidence].name}
                  </p>
                </div>
              </div>
            )}
            <div className="flex justify-center">
              <GameButton onClick={onExit}>{meeting.exitLabel}</GameButton>
            </div>
          </div>
        )}
      </div>
    </AmbientBackground>
  );
}

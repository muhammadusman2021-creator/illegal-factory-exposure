import { useState } from "react";
import { AmbientBackground, ChapterHeader, GameButton, EvidenceIcon } from "./ui";
import { EVIDENCE, SUSPECTS, type EvidenceId, type GameState, type SuspectId } from "../game/data";

export function EvidenceBoard({
  state,
  onReviewDone,
}: {
  state: GameState;
  onReviewDone: () => void;
}) {
  const [selected, setSelected] = useState<EvidenceId | null>(null);
  const evidence = state.evidence.map((id) => EVIDENCE[id]);

  return (
    <AmbientBackground>
      <ChapterHeader title="The Evidence Board" subtitle="What you've learned" />
      <div className="px-6 pt-5">
        <p className="mx-auto max-w-2xl text-center text-sm leading-relaxed text-ink-300">
          Review your evidence and observations before naming the traitor.
        </p>
      </div>

      <div className="flex flex-1 flex-col px-6 py-6">
        <div className="mx-auto w-full max-w-3xl">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {evidence.length === 0 && (
              <p className="col-span-full py-8 text-center text-sm text-ink-500">
                No physical evidence yet. Meet your contacts to collect clues.
              </p>
            )}
            {evidence.map((item) => (
              <button
                key={item.id}
                onClick={() => setSelected(item.id)}
                className={`flex flex-col items-center gap-2 rounded-lg border p-4 transition-all ${
                  selected === item.id
                    ? "border-ember-500/60 bg-ember-500/10"
                    : "border-ink-700 bg-ink-800/60 hover:border-ember-600/40"
                }`}
              >
                <span className="text-ember-400">
                  <EvidenceIcon icon={item.icon} />
                </span>
                <span className="text-center text-xs font-medium text-ink-200">
                  {item.name}
                </span>
              </button>
            ))}
          </div>

          {selected && EVIDENCE[selected] && (
            <div className="mt-5 animate-fade-in rounded-lg border border-ink-700 bg-ink-800/60 p-5">
              <p className="font-cinzel text-sm font-semibold text-ember-400">
                {EVIDENCE[selected].name}
              </p>
              <p className="mt-2 text-sm leading-relaxed text-ink-200">
                {EVIDENCE[selected].description}
              </p>
            </div>
          )}

          <div className="mt-6 rounded-lg border border-ink-700 bg-ink-900/60 p-5">
            <p className="text-xs uppercase tracking-[0.2em] text-ink-400">
              Clues Discovered
            </p>
            {state.clues.length === 0 ? (
              <p className="mt-2 text-sm text-ink-500">No suspicious observations yet.</p>
            ) : (
              <ul className="mt-3 space-y-2">
                {state.clues.map((clue, i) => (
                  <li key={i} className="flex gap-2 text-sm text-ink-200">
                    <span className="text-ember-500">◆</span>
                    <span className="leading-relaxed">{clue}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="mt-5 rounded-lg border border-rust-500/30 bg-rust-500/5 p-5">
            <p className="text-xs uppercase tracking-[0.2em] text-rust-400">
              Review
            </p>
            <p className="mt-2 text-sm leading-relaxed text-ink-200">
              Someone you trusted has been feeding Malik your every move. The
              threat text, the gang finding your identity, the chase through the
              city — all of it points to a single person.
            </p>
          </div>

          <div className="mt-6 flex justify-center">
            <GameButton onClick={onReviewDone}>
              Make Your Accusation →
            </GameButton>
          </div>
        </div>
      </div>
    </AmbientBackground>
  );
}

export function AccusationScene({
  state,
  onAccuse,
  onBack,
}: {
  state: GameState;
  onAccuse: (suspect: SuspectId) => void;
  onBack: () => void;
}) {
  const [selected, setSelected] = useState<SuspectId | null>(null);
  const [confirmed, setConfirmed] = useState(false);
  const suspects = Object.values(SUSPECTS);

  return (
    <AmbientBackground>
      <ChapterHeader title="Make Your Accusation" subtitle="Who is the traitor?" />
      <div className="px-6 pt-5">
        <p className="mx-auto max-w-2xl text-center text-sm leading-relaxed text-ink-300">
          Four suspects. One traitor. Match the clues to the person.
        </p>
        <p className="mx-auto mt-2 max-w-2xl text-center text-xs text-rust-400">
          Select carefully. You may be wrong, but not many times. (
          {state.maxWrong - state.wrongAccusations} mistakes left)
        </p>
      </div>

      <div className="flex flex-1 flex-col px-6 py-6">
        <div className="mx-auto w-full max-w-3xl space-y-3">
          {suspects.map((s) => (
            <button
              key={s.id}
              onClick={() => setSelected(s.id)}
              disabled={confirmed}
              className={`flex w-full items-start gap-4 rounded-lg border p-4 text-left transition-all disabled:opacity-60 ${
                selected === s.id
                  ? "border-blood-600/60 bg-blood-600/10"
                  : "border-ink-700 bg-ink-800/60 hover:border-rust-500/50"
              }`}
            >
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full border border-ink-600 bg-ink-900 text-lg font-cinzel font-bold text-ink-200">
                {s.name[0]}
              </div>
              <div className="flex-1">
                <p className="font-cinzel text-sm font-semibold text-ink-100">{s.name}</p>
                <p className="text-xs text-ink-400">{s.role}</p>
                <p className="mt-2 text-xs leading-relaxed text-ink-300">{s.description}</p>
              </div>
            </button>
          ))}
        </div>

        <div className="mt-7 flex justify-center gap-3">
          <GameButton variant="ghost" onClick={onBack} disabled={confirmed}>
            Back
          </GameButton>
          <GameButton
            variant="danger"
            disabled={!selected || confirmed}
            onClick={() => {
              if (selected) {
                setConfirmed(true);
                onAccuse(selected);
              }
            }}
          >
            Confirm Accusation
          </GameButton>
        </div>
      </div>
    </AmbientBackground>
  );
}

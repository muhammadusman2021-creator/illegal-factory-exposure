import { useEffect, useState } from "react";
import { AmbientBackground, ChapterHeader, GameButton } from "./ui";

const STEPS = [
  "Rain hits corrugated iron. The antenna hums above you. This is the only way out.",
  "You reach the broadcast antenna and upload the recording.",
  "Uploading… 12%… 47%… 89%…",
  "Signal locked. The recording is broadcasting to every newsroom in the city.",
];

export function BroadcastScene({ onComplete }: { onComplete: () => void }) {
  const [step, setStep] = useState(0);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (step !== 2) return;
    const interval = window.setInterval(() => {
      setProgress((p) => {
        if (p >= 100) {
          window.clearInterval(interval);
          setStep(3);
          return 100;
        }
        return p + 4;
      });
    }, 80);
    return () => window.clearInterval(interval);
  }, [step]);

  return (
    <AmbientBackground>
      <ChapterHeader title="The Truth Goes Live" subtitle="The Last Stand" />
      <div className="flex flex-1 flex-col items-center justify-center px-6 py-6">
        <div className="w-full max-w-md text-center">
          {step === 0 && (
            <div className="animate-fade-in space-y-6">
              <p className="font-cinzel text-lg leading-relaxed text-ink-100">
                {STEPS[0]}
              </p>
              <GameButton onClick={() => setStep(1)}>
                Reach the broadcast antenna and upload the recording
              </GameButton>
            </div>
          )}
          {step === 1 && (
            <div className="animate-fade-in space-y-6">
              <p className="font-cinzel text-lg text-ember-400 text-glow">
                {STEPS[1]}
              </p>
              <GameButton onClick={() => setStep(2)}>Begin upload</GameButton>
            </div>
          )}
          {step === 2 && (
            <div className="animate-fade-in space-y-4">
              <p className="text-sm uppercase tracking-[0.2em] text-ink-400">
                Uploading
              </p>
              <div className="h-3 w-full overflow-hidden rounded-full bg-ink-800 ring-1 ring-ink-700">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-ember-500 to-rust-500 transition-all duration-75"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <p className="font-cinzel text-2xl font-bold text-ember-400 text-glow">
                {progress}%
              </p>
            </div>
          )}
          {step === 3 && (
            <div className="animate-fade-in space-y-6">
              <p className="font-cinzel text-xl leading-relaxed text-ember-400 text-glow">
                {STEPS[3]}
              </p>
              <GameButton onClick={onComplete}>The truth is out →</GameButton>
            </div>
          )}
        </div>
      </div>
    </AmbientBackground>
  );
}

import { useEffect, useRef, useState } from "react";
import { AmbientBackground, ChapterHeader, GameButton, SuspicionMeter } from "./ui";

type Obstacle = { id: number; lane: number; y: number; kind: "wall" | "gap" };

const LANES = 3;
const SPAWN_INTERVAL = 1400;
const SPEED = 1.4;

export function CityChaseScene({
  onComplete,
  onCaught,
}: {
  onComplete: () => void;
  onCaught: () => void;
}) {
  const [playerLane, setPlayerLane] = useState(1);
  const [obstacles, setObstacles] = useState<Obstacle[]>([]);
  const [suspicion, setSuspicion] = useState(0);
  const [status, setStatus] = useState<"playing" | "won" | "caught">("playing");
  const [timeLeft, setTimeLeft] = useState(18);
  const laneRef = useRef(1);
  const idRef = useRef(0);
  const tickRef = useRef(0);

  useEffect(() => {
    laneRef.current = playerLane;
  }, [playerLane]);

  const move = (lane: number) => {
    if (status !== "playing") return;
    setPlayerLane(Math.max(0, Math.min(LANES - 1, lane)));
  };

  useEffect(() => {
    if (status !== "playing") return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft" || e.key === "a") move(laneRef.current - 1);
      if (e.key === "ArrowRight" || e.key === "d") move(laneRef.current + 1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [status]);

  useEffect(() => {
    if (status !== "playing") return;
    const timer = window.setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          setStatus("won");
          window.setTimeout(() => onComplete(), 1200);
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => window.clearInterval(timer);
  }, [status, onComplete]);

  useEffect(() => {
    if (status !== "playing") return;
    const spawn = window.setInterval(() => {
      const lane = Math.floor(Math.random() * LANES);
      setObstacles((prev) => [
        ...prev,
        { id: idRef.current++, lane, y: 100, kind: "wall" },
      ]);
    }, SPAWN_INTERVAL);
    return () => window.clearInterval(spawn);
  }, [status]);

  useEffect(() => {
    if (status !== "playing") return;
    const raf = window.setInterval(() => {
      tickRef.current += 1;
      setObstacles((prev) =>
        prev
          .map((o) => ({ ...o, y: o.y - SPEED }))
          .filter((o) => o.y > -15),
      );
      setObstacles((prev) => {
        const hit = prev.find((o) => o.lane === laneRef.current && o.y <= 12 && o.y >= -4);
        if (hit) {
          setStatus("caught");
          setSuspicion(100);
          window.setTimeout(() => onCaught(), 1400);
        }
        return prev;
      });
    }, 40);
    return () => window.clearInterval(raf);
  }, [status, onCaught]);

  return (
    <AmbientBackground>
      <ChapterHeader title="The Gathering Dark" subtitle="On the run" />
      <div className="px-6 pt-5">
        <div className="mx-auto flex max-w-2xl items-end justify-between gap-4">
          <div className="flex-1">
            <SuspicionMeter value={suspicion} max={100} />
          </div>
          <div className="text-right">
            <p className="text-[10px] uppercase tracking-[0.2em] text-ink-400">Time</p>
            <p className={`font-cinzel text-2xl font-bold ${timeLeft <= 5 ? "text-blood-400" : "text-ember-400"}`}>
              {timeLeft}s
            </p>
          </div>
        </div>
        <p className="mx-auto mt-3 max-w-xl text-center text-sm text-ink-300">
          Reach the safe house before the gang catches you. Dodge the roadblocks —
          weave between the three lanes.
        </p>
      </div>

      <div className="flex flex-1 flex-col items-center justify-center px-6 py-4">
        <div className="relative h-[60vh] max-h-96 w-64 overflow-hidden rounded-xl border border-ink-700 bg-gradient-to-b from-ink-900 to-ink-950 shadow-2xl shadow-black/60">
          <div className="pointer-events-none absolute inset-0 vhs-grain opacity-30" />
          <div className="pointer-events-none absolute left-1/2 top-0 h-full w-px -translate-x-1/2 bg-ink-700/50" />

          {Array.from({ length: LANES }).map((_, lane) => (
            <div key={lane} className="absolute top-0 h-full" style={{ left: `${(lane / LANES) * 100}%`, width: `${100 / LANES}%` }}>
              {obstacles
                .filter((o) => o.lane === lane)
                .map((o) => (
                  <div
                    key={o.id}
                    className="absolute left-1/2 h-10 w-[80%] -translate-x-1/2 rounded-md border border-blood-600/50 bg-blood-600/20 shadow-lg shadow-blood-600/30"
                    style={{ bottom: `${o.y}%` }}
                  >
                    <div className="flex h-full items-center justify-center text-blood-400/80">
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="h-5 w-5">
                        <path d="M5 12h14M5 7h14M5 17h14" />
                      </svg>
                    </div>
                  </div>
                ))}
            </div>
          ))}

          {Array.from({ length: 6 }).map((_, i) => (
            <div
              key={i}
              className="absolute left-1/2 h-8 w-10 -translate-x-1/2 rounded border border-ink-700/40 bg-ink-800/40"
              style={{ bottom: `${(tickRef.current * SPEED * 2 + i * 18) % 108 - 10}%` }}
            />
          ))}

          {status === "playing" && (
            <div
              className="absolute bottom-4 left-1/2 -translate-x-1/2 transition-all duration-150"
              style={{ left: `${((playerLane + 0.5) / LANES) * 100}%` }}
            >
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-ember-400 to-rust-500 text-ink-950 shadow-lg shadow-ember-500/50">
                <svg viewBox="0 0 24 24" fill="currentColor" className="h-5 w-5">
                  <path d="M13 2L4 14h7l-2 8 9-12h-7z" />
                </svg>
              </div>
            </div>
          )}

          {status === "caught" && (
            <div className="absolute inset-0 flex items-center justify-center bg-ink-950/70 backdrop-blur-sm">
              <p className="animate-shake font-cinzel text-2xl text-blood-500 blood-glow">Caught</p>
            </div>
          )}
          {status === "won" && (
            <div className="absolute inset-0 flex items-center justify-center bg-ink-950/70 backdrop-blur-sm">
              <p className="animate-fade-in font-cinzel text-xl text-ember-400 text-glow">Safe house reached</p>
            </div>
          )}
        </div>

        {status === "playing" && (
          <>
            <div className="mt-5 flex gap-2">
              {Array.from({ length: LANES }).map((_, lane) => (
                <GameButton
                  key={lane}
                  variant={playerLane === lane ? "primary" : "ghost"}
                  onClick={() => move(lane)}
                  className="px-5 py-2 text-xs"
                >
                  {lane === 0 ? "◄" : lane === 1 ? "▲" : "►"}
                </GameButton>
              ))}
            </div>
            <p className="mt-3 text-[10px] uppercase tracking-[0.2em] text-ink-500">
              Arrow keys / A / D
            </p>
          </>
        )}
      </div>
    </AmbientBackground>
  );
}

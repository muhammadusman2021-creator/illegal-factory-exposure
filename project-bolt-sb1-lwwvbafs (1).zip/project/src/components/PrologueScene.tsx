import { useState } from "react";
import { AmbientBackground, GameButton, ChapterHeader } from "./ui";
import { useTypewriter } from "../hooks/saveGame";

const PROLOGUE_LINES = [
  "Rain hits corrugated iron. Somewhere a metal door bangs in the wind.",
  "The warehouse stinks of diesel. You crouch behind a crate, phone trembling in your hand.",
  "Through the gap, you see them — Malik's men. The crime happens in front of your lens. Faces clear. Voices audible.",
  "You slip out the way you came in. But a guard turns. For one second, your eyes meet.",
  "They know your face now.",
];

export function PrologueScene({ onComplete }: { onComplete: (name: string) => void }) {
  const [name, setName] = useState("");
  const [phase, setPhase] = useState<"intro" | "name">("intro");
  const [lineIndex, setLineIndex] = useState(0);
  const { displayed, done, skip } = useTypewriter(PROLOGUE_LINES[lineIndex], 24, phase === "intro");

  const advance = () => {
    if (!done) {
      skip();
      return;
    }
    if (lineIndex < PROLOGUE_LINES.length - 1) {
      setLineIndex((i) => i + 1);
      return;
    }
    setPhase("name");
  };

  if (phase === "name") {
    return (
      <AmbientBackground>
        <div className="flex flex-1 flex-col items-center justify-center px-6">
          <ChapterHeader title="Prologue" subtitle="What is your name, student?" />
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (name.trim()) onComplete(name.trim());
            }}
            className="mt-10 w-full max-w-sm space-y-5"
          >
            <input
              autoFocus
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={24}
              placeholder="Enter your name"
              className="w-full rounded-lg border border-ink-600 bg-ink-900/80 px-4 py-3 text-center font-cinzel text-lg text-ink-50 placeholder:font-sans placeholder:text-sm placeholder:text-ink-500 focus:border-ember-500/60 focus:outline-none focus:ring-2 focus:ring-ember-500/30"
            />
            <div className="flex justify-center">
              <GameButton type="submit" disabled={!name.trim()}>
                Begin the Investigation
              </GameButton>
            </div>
          </form>
        </div>
      </AmbientBackground>
    );
  }

  return (
    <AmbientBackground>
      <div
        className="flex flex-1 flex-col items-center justify-center px-6 cursor-pointer"
        onClick={advance}
      >
        <ChapterHeader title="Prologue" subtitle="The warehouse" />
        <div className="mt-12 min-h-[6rem] max-w-xl text-center">
          <p className="font-cinzel text-xl leading-relaxed text-ink-100 sm:text-2xl">
            {displayed}
            <span className={`ml-0.5 inline-block ${done ? "" : "animate-pulse-glow"}`}>▋</span>
          </p>
        </div>
        <p className="mt-12 text-xs uppercase tracking-[0.3em] text-ink-500">
          {done ? "Tap to continue" : ""}
        </p>
      </div>
    </AmbientBackground>
  );
}

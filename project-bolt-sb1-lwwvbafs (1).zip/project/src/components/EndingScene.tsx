import { AmbientBackground, GameButton, ChapterHeader } from "./ui";
import { SUSPECTS, type SuspectId, type GameState } from "../game/data";

export function EndingScene({
  variant,
  state,
  onPlayAgain,
  onTitle,
}: {
  variant: "truth" | "caught" | "wrong";
  state: GameState;
  accused?: SuspectId;
  onPlayAgain: () => void;
  onTitle: () => void;
}) {
  if (variant === "truth") {
    return (
      <AmbientBackground>
        <ChapterHeader title="The Bigger Truth" subtitle="The truth is out" />
        <div className="flex flex-1 flex-col items-center justify-center px-6 py-6">
          <div className="w-full max-w-xl animate-fade-in space-y-5 text-center">
            <p className="font-cinzel text-lg leading-relaxed text-ember-400 text-glow">
              You reached the antenna. The recording is broadcasting to every
              newsroom in the city. Malik's network is falling apart in real time.
            </p>
            <div className="rounded-lg border border-ember-600/40 bg-ember-500/5 p-5 text-left">
              <p className="text-xs uppercase tracking-[0.2em] text-ember-400">
                The verdict
              </p>
              <p className="mt-2 text-sm leading-relaxed text-ink-100">
                {SUSPECTS.khan.rightReason}
              </p>
            </div>
            <p className="text-sm leading-relaxed text-ink-300">
              {state.playerName}, you did what no witness before you could. You
              didn't trust the system. You trusted the evidence. And the truth
              went live.
            </p>
            <div className="flex justify-center gap-3 pt-4">
              <GameButton onClick={onPlayAgain}>Play Again</GameButton>
              <GameButton variant="ghost" onClick={onTitle}>
                Back to Title
              </GameButton>
            </div>
          </div>
        </div>
      </AmbientBackground>
    );
  }

  if (variant === "caught") {
    return (
      <AmbientBackground>
        <ChapterHeader title="The End" subtitle="Caught" />
        <div className="flex flex-1 flex-col items-center justify-center px-6 py-6">
          <div className="w-full max-w-xl animate-fade-in space-y-5 text-center">
            <p className="font-cinzel text-xl text-blood-500 blood-glow">Time's up</p>
            <p className="text-sm leading-relaxed text-ink-300">
              The gang knows your name. They're in every street, every market.
              Running would save you — but the recording would stay buried, and
              Malik's network would keep growing.
            </p>
            <p className="text-sm leading-relaxed text-ink-400">
              The shift ended. The guards sealed the exits. You'll have to try
              again another night.
            </p>
            <div className="flex justify-center gap-3 pt-4">
              <GameButton onClick={onPlayAgain}>Try Again</GameButton>
              <GameButton variant="ghost" onClick={onTitle}>
                Back to Title
              </GameButton>
            </div>
          </div>
        </div>
      </AmbientBackground>
    );
  }

  const accused = state.accusation ?? "bilal";
  const suspect = SUSPECTS[accused];
  const outOfChances = state.wrongAccusations >= state.maxWrong;

  return (
    <AmbientBackground>
      <ChapterHeader title="The End" subtitle={outOfChances ? "The Last" : "Wrong answer"} />
      <div className="flex flex-1 flex-col items-center justify-center px-6 py-6">
        <div className="w-full max-w-xl animate-fade-in space-y-5 text-center">
          <p className="font-cinzel text-lg text-blood-500 blood-glow">
            It was not {suspect.name}.
          </p>
          <p className="text-sm leading-relaxed text-ink-200">
            {suspect.wrongReason}
          </p>
          {outOfChances ? (
            <p className="text-sm leading-relaxed text-ink-400">
              You've accused too many innocents. Word reaches Malik before you can
              move. The recording dies with you. The witnesses who come after will
              never know how close you came.
            </p>
          ) : (
            <p className="text-sm leading-relaxed text-ink-400">
              Review what you have. Match the evidence to the suspect. Choose wrong,
              and the real traitor warns Malik — the broadcast fails, and you
              disappear like every witness before you.
            </p>
          )}
          <div className="flex justify-center gap-3 pt-4">
            <GameButton onClick={onPlayAgain}>
              {outOfChances ? "Try Again" : "Return to the Evidence"}
            </GameButton>
            <GameButton variant="ghost" onClick={onTitle}>
              Back to Title
            </GameButton>
          </div>
        </div>
      </div>
    </AmbientBackground>
  );
}

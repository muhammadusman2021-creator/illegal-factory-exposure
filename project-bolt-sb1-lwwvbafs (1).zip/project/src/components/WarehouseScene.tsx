import { useEffect, useState, useCallback } from "react";
import { AmbientBackground, GameButton, ChapterHeader, SuspicionMeter } from "./ui";

type Guard = {
  id: number;
  lane: number;
  pos: number;
  speed: number;
  dir: 1 | -1;
};

const LANES = 5;
const PLAYER_START = 0;
const EXIT_LANE = LANES - 1;

export function WarehouseScene({
  onComplete,
  onCaught,
}: {
  onComplete: () => void;
  onCaught: () => void;
}) {
  const [playerLane, setPlayerLane] = useState(PLAYER_START);
  const [moving, setMoving] = useState(false);
  const [guards, setGuards] = useState<Guard[]>(() =>
    [1, 2, 3].map((i, idx) => ({
      id: idx,
      lane: i,
      pos: 0.2 + idx * 0.25,
      speed: 0.004 + idx * 0.0015,
      dir: idx % 2 === 0 ? 1 : -1,
    })),
  );
  const [suspicion, setSuspicion] = useState(0);
  const [status, setStatus] = useState<"playing" | "won" | "caught">("playing");

  const move = useCallback(
    (dir: 1 | -1) => {
      if (moving || status !== "playing") return;
      setMoving(true);
      setPlayerLane((lane) => Math.max(0, Math.min(LANES - 1, lane + dir)));
      window.setTimeout(() => setMoving(false), 260);
    },
    [moving, status],
  );

  useEffect(() => {
    if (status !== "playing") return;
    const raf = window.setInterval(() => {
      setGuards((prev) =>
        prev.map((g) => {
          let pos = g.pos + g.speed * g.dir;
          let dir = g.dir;
          if (pos >= 1) {
            pos = 1;
            dir = -1;
          } else if (pos <= 0) {
            pos = 0;
            dir = 1;
          }
          return { ...g, pos, dir };
        }),
      );
    }, 32);
    return () => window.clearInterval(raf);
  }, [status]);

  useEffect(() => {
    if (status !== "playing") return;
    const collide = guards.some((g) => {
      if (g.lane !== playerLane) return false;
      return Math.abs(g.pos - 0.5) < 0.12;
    });
    if (collide) {
      setStatus("caught");
      setSuspicion((s) => Math.min(100, s + 40));
      window.setTimeout(() => onCaught(), 1400);
    }
  }, [guards, playerLane, status, onCaught]);

  useEffect(() => {
    if (status !== "playing") return;
    if (playerLane === EXIT_LANE) {
      setStatus("won");
      window.setTimeout(() => onComplete(), 1200);
    }
  }, [playerLane, status, onComplete]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowUp" || e.key === "w") move(1);
      if (e.key === "ArrowDown" || e.key === "s") move(-1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [move]);

  return (
    <AmbientBackground>
      <ChapterHeader title="The Last" subtitle="The warehouse" />
      <div className="px-6 pt-6">
        <div className="mx-auto max-w-2xl">
          <p className="mb-4 text-center text-sm text-ink-300">
            Grab your phone and the documents, then reach the exit. Guards patrol
            the lanes — slip past while they look away.
          </p>
          <SuspicionMeter value={suspicion} max={100} />
        </div>
      </div>

      <div className="flex flex-1 flex-col items-center justify-center px-6 py-6">
        <div className="relative w-full max-w-md overflow-hidden rounded-xl border border-ink-700 bg-ink-900/80 shadow-2xl shadow-black/50">
          <div className="space-y-2 p-4">
            {Array.from({ length: LANES }).map((_, lane) => (
              <div
                key={lane}
                className="relative h-14 overflow-hidden rounded-md bg-ink-800/70 ring-1 ring-ink-700/60"
              >
                <div className="absolute inset-0 vhs-grain opacity-30" />
                {lane === 0 && (
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[10px] uppercase tracking-widest text-ink-500">
                    Start
                  </span>
                )}
                {lane === EXIT_LANE && (
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] uppercase tracking-widest text-ember-400/80">
                    Exit →
                  </span>
                )}
                {lane === playerLane && (
                  <div
                    className={`absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 transition-all duration-200 ${moving ? "scale-110" : "scale-100"}`}
                  >
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-ember-400 to-rust-500 text-ink-950 shadow-lg shadow-ember-500/40">
                      <svg viewBox="0 0 24 24" fill="currentColor" className="h-4 w-4">
                        <circle cx="12" cy="8" r="4" />
                        <path d="M4 22c0-4 4-7 8-7s8 3 8 7" />
                      </svg>
                    </div>
                  </div>
                )}
                {guards
                  .filter((g) => g.lane === lane)
                  .map((g) => (
                    <div
                      key={g.id}
                      className="absolute top-1/2 -translate-y-1/2 transition-transform"
                      style={{ left: `${g.pos * 100}%`, transform: `translate(-50%, -50%) scaleX(${g.dir})` }}
                    >
                      <div className="flex h-7 w-7 items-center justify-center rounded-full border border-blood-600/40 bg-blood-600/30 text-blood-400 shadow-md shadow-blood-600/30">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-4 w-4">
                          <circle cx="12" cy="7" r="3" />
                          <path d="M5 22c0-4 3-6 7-6s7 2 7 6" />
                        </svg>
                      </div>
                    </div>
                  ))}
              </div>
            ))}
          </div>
        </div>

        {status === "playing" && (
          <>
            <div className="mt-6 flex gap-3">
              <GameButton variant="ghost" onClick={() => move(-1)} disabled={moving || playerLane === 0}>
                ▲ Back
              </GameButton>
              <GameButton variant="ghost" onClick={() => move(1)} disabled={moving || playerLane === EXIT_LANE}>
                Forward ▼
              </GameButton>
            </div>
            <p className="mt-3 text-[10px] uppercase tracking-[0.2em] text-ink-500">
              Arrow keys / W / S
            </p>
          </>
        )}

        {status === "caught" && (
          <div className="mt-8 animate-shake text-center">
            <p className="font-cinzel text-xl text-blood-500 blood-glow">Caught</p>
            <p className="mt-2 max-w-sm text-sm text-ink-300">
              A guard grabbed you in the dark. They drag you to Aslam's office.
              This story ends here — unless you try again.
            </p>
          </div>
        )}

        {status === "won" && (
          <div className="mt-8 animate-fade-in text-center">
            <p className="font-cinzel text-xl text-ember-400 text-glow">You slipped past them.</p>
            <p className="mt-2 max-w-sm text-sm text-ink-300">
              You slipped past the gang with the evidence intact. But they know
              your face now.
            </p>
          </div>
        )}
      </div>
    </AmbientBackground>
  );
}

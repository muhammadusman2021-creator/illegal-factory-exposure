import { type ReactNode } from "react";

export function AmbientBackground({ children }: { children?: ReactNode }) {
  return (
    <div className="relative min-h-screen overflow-hidden bg-ink-950">
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-ink-900 via-ink-950 to-black" />
      <div className="pointer-events-none absolute inset-0 vhs-grain opacity-40" />
      <div className="pointer-events-none absolute -top-40 left-1/2 h-80 w-[120%] -translate-x-1/2 rounded-full bg-ember-500/5 blur-3xl" />
      <div className="pointer-events-none absolute bottom-0 left-1/2 h-64 w-[120%] -translate-x-1/2 rounded-full bg-blood-600/5 blur-3xl" />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px animate-scan bg-gradient-to-r from-transparent via-ember-500/30 to-transparent" />
      <div className="relative z-10 min-h-screen flex flex-col">{children}</div>
    </div>
  );
}

export function GameButton({
  children,
  onClick,
  type = "button",
  variant = "primary",
  disabled,
  className = "",
}: {
  children: ReactNode;
  onClick?: () => void;
  type?: "button" | "submit" | "reset";
  variant?: "primary" | "ghost" | "danger";
  disabled?: boolean;
  className?: string;
}) {
  const base =
    "relative inline-flex items-center justify-center gap-2 rounded-md px-6 py-3 text-sm font-semibold tracking-wide transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-ember-500/60 disabled:opacity-40 disabled:cursor-not-allowed";
  const variants = {
    primary:
      "bg-gradient-to-r from-ember-500 to-rust-500 text-ink-950 hover:from-ember-400 hover:to-rust-400 shadow-lg shadow-ember-500/20 hover:shadow-ember-500/40",
    ghost:
      "bg-ink-800/60 text-ink-100 border border-ink-600 hover:border-ember-500/60 hover:bg-ink-700/60",
    danger:
      "bg-gradient-to-r from-blood-600 to-blood-700 text-ink-50 hover:from-blood-500 hover:to-blood-600 shadow-lg shadow-blood-600/20",
  };
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`${base} ${variants[variant]} ${className}`}
    >
      {children}
    </button>
  );
}

export function EvidenceIcon({ icon }: { icon: string }) {
  const paths: Record<string, ReactNode> = {
    video: (
      <path d="M4 5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2H4zm14 3.5l4-2v9l-4-2" />
    ),
    message: <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />,
    document: <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zm-1 7V3.5L18.5 9H13z" />,
    badge: <path d="M12 2l3 6 6 .9-4.5 4.3 1 6.3L12 16.5 6.5 19.5l1-6.3L3 8.9 9 8z" />,
    map: (
      <>
        <path d="M9 20l-6-2V4l6 2 6-2 6 2v14l-6-2-6 2z" />
        <path d="M9 6v14M15 4v14" />
      </>
    ),
    photo: (
      <>
        <rect x="3" y="3" width="18" height="18" rx="2" />
        <circle cx="9" cy="9" r="2" />
        <path d="M21 15l-5-5L5 21" />
      </>
    ),
    newspaper: (
      <>
        <rect x="3" y="4" width="18" height="16" rx="2" />
        <path d="M7 8h6M7 12h6M7 16h4M16 8h2M16 12h2M16 16h2" />
      </>
    ),
    sim: (
      <>
        <path d="M7 2h7l5 5v13a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2z" />
        <rect x="8" y="10" width="8" height="6" rx="1" />
      </>
    ),
  };
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      className="h-6 w-6"
    >
      {paths[icon] ?? paths.document}
    </svg>
  );
}

export function SuspicionMeter({ value, max }: { value: number; max: number }) {
  const pct = Math.min(100, (value / max) * 100);
  const color =
    pct > 75 ? "bg-blood-600" : pct > 45 ? "bg-rust-500" : "bg-ember-500";
  return (
    <div className="w-full">
      <div className="mb-1 flex items-center justify-between text-[10px] uppercase tracking-[0.2em] text-ink-400">
        <span>Suspicion Level</span>
        <span className={pct > 75 ? "text-blood-400" : "text-ink-300"}>
          {Math.round(pct)}%
        </span>
      </div>
      <div className="h-2 w-full overflow-hidden rounded-full bg-ink-800 ring-1 ring-ink-700">
        <div
          className={`h-full rounded-full transition-all duration-500 ${color}`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}

export function ChapterHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="animate-fade-in px-6 pt-10 text-center">
      <h2 className="font-cinzel text-2xl font-bold tracking-[0.15em] text-ember-400 text-glow sm:text-3xl">
        {title}
      </h2>
      {subtitle && (
        <p className="mt-2 text-xs uppercase tracking-[0.3em] text-ink-400">{subtitle}</p>
      )}
    </div>
  );
}

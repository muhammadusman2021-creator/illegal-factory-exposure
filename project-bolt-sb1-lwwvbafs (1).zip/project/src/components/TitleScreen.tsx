import { useState } from "react";
import { AmbientBackground, GameButton } from "./ui";
import type { SaveSummary } from "../hooks/saveGame";
import { supabaseConfigured } from "../lib/supabase";

export function TitleScreen({
  saves,
  loadingSaves,
  onNewGame,
  onContinue,
  onDeleteSave,
}: {
  saves: SaveSummary[];
  loadingSaves: boolean;
  onNewGame: () => void;
  onContinue: (save: SaveSummary) => void;
  onDeleteSave: (slot: string) => void;
}) {
  const [showSaves, setShowSaves] = useState(false);
  const hasSaves = saves.length > 0;

  return (
    <AmbientBackground>
      <div className="flex flex-1 flex-col items-center justify-center px-6 py-12">
        <div className="animate-fade-in text-center">
          <p className="mb-4 text-xs uppercase tracking-[0.5em] text-ink-400">
            A Story of
          </p>
          <h1 className="font-cinzel text-5xl font-bold leading-tight tracking-[0.1em] text-ember-400 text-glow sm:text-7xl">
            The Last
            <br />
            Witness
          </h1>
          <p className="mx-auto mt-6 max-w-md text-sm leading-relaxed text-ink-300">
            A university student records a crime he was never meant to see. The
            gang knows his face. The police cannot be trusted. One recording. One
            witness. One chance to expose the truth.
          </p>
        </div>

        <div className="mt-10 flex flex-col items-center gap-3">
          <GameButton onClick={onNewGame} className="min-w-[220px]">
            New Game
          </GameButton>
          {supabaseConfigured && hasSaves && (
            <GameButton
              variant="ghost"
              onClick={() => setShowSaves((s) => !s)}
              className="min-w-[220px]"
            >
              {showSaves ? "Hide Saves" : "Saved Games"}
            </GameButton>
          )}
          {supabaseConfigured && !hasSaves && !loadingSaves && (
            <p className="text-xs text-ink-500">No saved games yet.</p>
          )}
          {supabaseConfigured && loadingSaves && (
            <p className="text-xs text-ink-400">Loading saves…</p>
          )}
          {!supabaseConfigured && (
            <p className="text-xs text-ink-500">Cloud saves unavailable — progress won't persist.</p>
          )}
        </div>

        {showSaves && hasSaves && (
          <div className="mt-8 w-full max-w-md animate-fade-in space-y-3">
            {saves.map((save) => (
              <div
                key={save.id}
                className="group flex items-center justify-between rounded-lg border border-ink-700 bg-ink-800/60 p-4 transition-colors hover:border-ember-500/50"
              >
                <button
                  onClick={() => onContinue(save)}
                  className="flex-1 text-left"
                >
                  <p className="font-cinzel text-sm font-semibold text-ink-100">
                    {save.playerName || "Witness"}
                  </p>
                  <p className="mt-1 text-xs text-ink-400">
                    {save.evidenceCount} evidence · {sceneLabel(save.scene)}
                  </p>
                  <p className="mt-0.5 text-[10px] text-ink-500">
                    {new Date(save.updatedAt).toLocaleString()}
                  </p>
                </button>
                <div className="flex gap-2">
                  <GameButton
                    variant="ghost"
                    onClick={() => onContinue(save)}
                    className="px-3 py-2 text-xs"
                  >
                    Play
                  </GameButton>
                  <button
                    onClick={() => onDeleteSave(save.slot)}
                    className="rounded-md border border-ink-600 px-3 py-2 text-xs text-ink-400 transition-colors hover:border-blood-600/60 hover:text-blood-400"
                    aria-label="Delete save"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        <p className="mt-auto pt-12 text-[10px] uppercase tracking-[0.3em] text-ink-600">
          Tap to continue
        </p>
      </div>
    </AmbientBackground>
  );
}

function sceneLabel(scene: string): string {
  const map: Record<string, string> = {
    title: "Title Screen",
    prologue: "Prologue",
    warehouse: "The warehouse",
    city_chase: "On the run",
    contacts: "Contacts",
    meeting_bilal: "Met Bilal",
    meeting_khan: "Met Khan",
    meeting_maira: "Met Maira",
    meeting_usman: "Met Usman",
    evidence_board: "Evidence Board",
    accusation: "Accusation",
    broadcast: "The Broadcast",
    ending_truth: "The truth is out",
    ending_caught: "Caught",
    ending_wrong: "The End",
  };
  return map[scene] ?? scene;
}

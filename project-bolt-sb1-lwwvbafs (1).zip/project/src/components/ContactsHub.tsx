import { AmbientBackground, ChapterHeader, GameButton, SuspicionMeter } from "./ui";
import { MEETINGS, type GameState } from "../game/data";

export function ContactsHub({
  state,
  onPick,
}: {
  state: GameState;
  onPick: (meetingId: string) => void;
}) {
  const allVisited =
    state.visited.bilal && state.visited.khan && state.visited.maira && state.visited.usman;

  return (
    <AmbientBackground>
      <ChapterHeader title="Your Phone" subtitle="Choose a contact to meet" />
      <div className="px-6 pt-5">
        <div className="mx-auto max-w-2xl">
          <SuspicionMeter value={state.suspicion} max={state.suspicionMax} />
        </div>
        <p className="mx-auto mt-4 max-w-xl text-center text-sm leading-relaxed text-ink-300">
          Meet each contact. Listen carefully. What they say — and what they
          don't — will reveal the traitor.
        </p>
      </div>

      <div className="flex flex-1 flex-col items-center px-6 py-6">
        <div className="grid w-full max-w-2xl gap-3 sm:grid-cols-2">
          {MEETINGS.map((m) => {
            const visited = state.visited[m.visitedKey];
            return (
              <button
                key={m.id}
                onClick={() => onPick(m.id)}
                className="group relative overflow-hidden rounded-lg border border-ink-700 bg-ink-800/60 p-5 text-left transition-all hover:border-ember-500/50 hover:bg-ink-700/60"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-cinzel text-base font-semibold text-ink-100 group-hover:text-ember-400">
                      {m.title}
                    </p>
                    <p className="mt-1 text-xs text-ink-400">{m.location}</p>
                  </div>
                  {visited && (
                    <span className="shrink-0 rounded-full border border-ember-600/40 bg-ember-500/10 px-2 py-0.5 text-[10px] uppercase tracking-widest text-ember-400">
                      Met
                    </span>
                  )}
                </div>
                <p className="mt-3 text-xs leading-relaxed text-ink-300">
                  {m.objective}
                </p>
              </button>
            );
          })}
        </div>

        <div className="mt-8">
          <GameButton onClick={() => onPick("evidence_board")} variant="primary">
            Review the Evidence →
          </GameButton>
          {!allVisited && (
            <p className="mt-3 text-center text-[11px] text-ink-500">
              You can review now, but meeting everyone sharpens your case.
            </p>
          )}
        </div>
      </div>
    </AmbientBackground>
  );
}

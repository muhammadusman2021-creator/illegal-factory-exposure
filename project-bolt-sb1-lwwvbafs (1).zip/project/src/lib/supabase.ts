import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import type { GameState } from "../game/data";

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

export const supabaseConfigured = Boolean(url && anonKey);

export const supabase: SupabaseClient = supabaseConfigured
  ? createClient(url!, anonKey!, { auth: { persistSession: false } })
  : ({} as SupabaseClient);

export type SaveRow = {
  id: string;
  slot: string;
  player_name: string;
  state: GameState;
  updated_at: string;
};

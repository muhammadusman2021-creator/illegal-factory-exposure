import type { Config } from "tailwindcss";

export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        ink: {
          50: "#e7e5e4",
          100: "#d6d3d1",
          200: "#a8a29e",
          300: "#78716c",
          400: "#57534e",
          500: "#3f3f46",
          600: "#27272a",
          700: "#1c1917",
          800: "#15140f",
          900: "#0c0b08",
          950: "#050504",
        },
        ember: {
          300: "#fcd34d",
          400: "#fbbf24",
          500: "#f59e0b",
          600: "#d97706",
        },
        blood: {
          400: "#f87171",
          500: "#ef4444",
          600: "#dc2626",
          700: "#b91c1c",
        },
        rust: {
          400: "#f97316",
          500: "#ea580c",
          600: "#c2410c",
        },
      },
      fontFamily: {
        cinzel: ["Cinzel", "serif"],
        sans: ["Inter", "system-ui", "sans-serif"],
      },
      keyframes: {
        fadeIn: {
          "0%": { opacity: "0", transform: "translateY(8px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        pulseGlow: {
          "0%, 100%": { opacity: "0.5" },
          "50%": { opacity: "1" },
        },
        flicker: {
          "0%, 100%": { opacity: "1" },
          "45%": { opacity: "0.85" },
          "50%": { opacity: "0.6" },
          "55%": { opacity: "0.9" },
        },
        scan: {
          "0%": { transform: "translateY(-100%)" },
          "100%": { transform: "translateY(100vh)" },
        },
        shake: {
          "0%, 100%": { transform: "translateX(0)" },
          "20%": { transform: "translateX(-6px)" },
          "40%": { transform: "translateX(6px)" },
          "60%": { transform: "translateX(-4px)" },
          "80%": { transform: "translateX(4px)" },
        },
      },
      animation: {
        "fade-in": "fadeIn 0.7s ease-out both",
        "pulse-glow": "pulseGlow 2.4s ease-in-out infinite",
        flicker: "flicker 4s linear infinite",
        scan: "scan 6s linear infinite",
        shake: "shake 0.4s ease-in-out",
      },
    },
  },
  plugins: [],
} satisfies Config;

<img src="docs/banner.svg" alt="The Last Witness" width="100%" />

# The Last Witness

A narrative thriller game. You are a university student who recorded a crime you
were never meant to see. The gang knows your face. The police cannot be trusted.
One recording. One witness. One chance to expose the truth.

Meet your contacts, collect evidence, and identify the traitor before you
broadcast the recording to the city.

[![CI](https://github.com/YOUR-USERNAME/the-last-witness/actions/workflows/ci.yml/badge.svg)](https://github.com/YOUR-USERNAME/the-last-witness/actions/workflows/ci.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-ember500.svg)](LICENSE)

## Story

You are **Saad**, a student who snuck into Malik's warehouse and captured a crime
on video. Now the gang is hunting you, the police can't be trusted, and one of
the four people you confided in is feeding Malik your every move.

- **Bilal** — your childhood friend, a taxi driver who knows every alley
- **Inspector Khan** — claims to be an honest cop investigating Malik off the books
- **Maira** — an investigative journalist who's been waiting three years for proof
- **Professor Usman** — your mentor, who taught you to believe in justice

Listen to what they say. Listen to what they *don't* say. Match the evidence to
the person. Choose wrong, and you disappear like every witness before you.

## Stack

- **Vite + React + TypeScript** — frontend
- **Tailwind CSS** — custom ink / ember / blood / rust palette, Cinzel + Inter fonts
- **Supabase** — save / load game state (Postgres + RLS)

## Getting started

```bash
npm install
npm run dev
```

Create a `.env` file (see `.env.example`) with your Supabase project URL and anon
key. The app expects a `saves` table — the schema is applied via the Supabase
migration during build.

## Scripts

| Command | Description |
|---------|-------------|
| `npm run dev` | Start the dev server |
| `npm run build` | Typecheck + production build |
| `npm run preview` | Preview the production build |

## Project structure

```
src/
  game/
    data.ts          # chapters, dialogue, evidence, suspects, accusation logic
  components/
    TitleScreen.tsx        # title + saved games
    PrologueScene.tsx      # opening narrative + name entry
    WarehouseScene.tsx     # stealth mini-game (slip past guards)
    CityChaseScene.tsx     # lane-dodging chase mini-game
    MeetingScene.tsx       # contact dialogue + clue/evidence collection
    ContactsHub.tsx        # choose which contact to meet
    EvidenceBoard.tsx      # evidence review + accusation
    BroadcastScene.tsx     # upload-the-recording finale
    EndingScene.tsx        # truth / caught / wrong-accusation endings
    ui.tsx                 # shared UI primitives + ambient background
  hooks/
    saveGame.ts      # Supabase save/load hooks + typewriter hook
  lib/
    supabase.ts      # Supabase client
  App.tsx            # scene router + game state
```

## How to play

1. Enter your name in the prologue.
2. Slip past the guards in the warehouse.
3. Dodge the roadblocks to reach the safe house.
4. Meet each contact — listen to what they say, and what they don't.
5. Review your evidence, then accuse the traitor.
6. If you're right, broadcast the recording. If you're wrong, try again — but
   you only have two mistakes.

## License

[MIT](LICENSE)
